public class P_18 {
    public static void main(String[] args) {
        System.out.format("Current Date Time %tc \n", System.currentTimeMillis());
    }
}
