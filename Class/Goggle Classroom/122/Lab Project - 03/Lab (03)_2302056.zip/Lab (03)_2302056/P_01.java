package class_assignment;

public class P_01 {
    public static void main(String[] args) {
        System.out.println("Name        : SHOVON");
        System.out.println("Address     : Satkhira");
        System.out.println("Number      : 01705199367");
        System.out.println("E-mail      : sakibul944@gmail.com");
        System.out.println("Faculty     : CSE");
        System.out.println("University  : PSTU");
    }
}
