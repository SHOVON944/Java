package class_assignment;
import java.util.Scanner;
public class P_03 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter your name : ");
        String name = scan.nextLine();
        System.out.println("Your name is : " + name);
    }
}
