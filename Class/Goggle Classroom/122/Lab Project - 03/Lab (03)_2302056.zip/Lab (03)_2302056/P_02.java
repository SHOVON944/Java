package class_assignment;

public class P_02 {
    public static void main(String[] args) {
        int radius = 3;
        double area = Math.PI * Math.pow(radius, 2);
        System.out.println("The area is : " + area);
    }
}
